/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./src/js/src/component.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): component.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var Component = /*#__PURE__*/function () {
  /**
   * Component constructor
   * @param {element} element 
   */
  function Component(element) {
    _classCallCheck(this, Component);
    // Component [id] value.
    this.element = element;

    // Component element element.
    this.id = this.element.getAttribute("id");

    // Element with [aria-controls] to trigger component event.  
    this.controls = document.querySelectorAll("[aria-controls=\"".concat(this.id, "\"]"));
    var _iterator = _createForOfIteratorHelper(this.controls),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var control = _step.value;
        control.addEventListener("click", this);
      }

      // -------------------------< Put additional codes here >-------------------------
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }

  /**
   * Component event handler.
   * @param {object} event 
   */
  _createClass(Component, [{
    key: "handleEvent",
    value: function handleEvent(event) {
      if (event.target.hasAttribute("data-bc-toggle")) {
        if (event.target.getAttribute("data-bc-toggle") === "show") {
          this.show();
        } else if (event.target.getAttribute("data-bc-toggle") === "hide") {
          this.hide();
        }
      }

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Component show handler.
     */
  }, {
    key: "show",
    value: function show() {
      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Component hide handler.
     */
  }, {
    key: "hide",
    value: function hide() {
      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Component toggle handler.
     */
  }, {
    key: "toggle",
    value: function toggle() {
      // -------------------------< Put additional codes here >-------------------------
    }
  }]);
  return Component;
}();
/* harmony default export */ const component = (Component);
;// CONCATENATED MODULE: ./src/js/src/alert.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): alert.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



function alert_typeof(obj) { "@babel/helpers - typeof"; return alert_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, alert_typeof(obj); }
function alert_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function alert_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, alert_toPropertyKey(descriptor.key), descriptor); } }
function alert_createClass(Constructor, protoProps, staticProps) { if (protoProps) alert_defineProperties(Constructor.prototype, protoProps); if (staticProps) alert_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function alert_toPropertyKey(arg) { var key = alert_toPrimitive(arg, "string"); return alert_typeof(key) === "symbol" ? key : String(key); }
function alert_toPrimitive(input, hint) { if (alert_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (alert_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function _get() { if (typeof Reflect !== "undefined" && Reflect.get) { _get = Reflect.get.bind(); } else { _get = function _get(target, property, receiver) { var base = _superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(arguments.length < 3 ? target : receiver); } return desc.value; }; } return _get.apply(this, arguments); }
function _superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = _getPrototypeOf(object); if (object === null) break; } return object; }
function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) _setPrototypeOf(subClass, superClass); }
function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _possibleConstructorReturn(self, call) { if (call && (alert_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }
function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

var Alert = /*#__PURE__*/function (_Component) {
  _inherits(Alert, _Component);
  var _super = _createSuper(Alert);
  /**
   * Alert constructor.
   * @param {element} element 
   */
  function Alert(element) {
    var _this;
    alert_classCallCheck(this, Alert);
    _this = _super.call(this, element);

    // -------------------------< Put additional codes here >-------------------------
    // Element's parent element.
    _this.parentElement = _this.element.parentElement;
    return _this;
  }

  /**
   * Alert event handler.
   * @param {object} event 
   */
  alert_createClass(Alert, [{
    key: "handleEvent",
    value: function handleEvent(event) {
      _get(_getPrototypeOf(Alert.prototype), "handleEvent", this).call(this, event);

      // If [data-bc-toggle] attribute is not defined on element with [aria-controls] attribute.
      if (!event.target.hasAttribute("data-bc-toggle")) this.hide();

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Alert hide handler.
     */
  }, {
    key: "hide",
    value: function hide() {
      _get(_getPrototypeOf(Alert.prototype), "hide", this).call(this);
      this.element.remove();

      // -------------------------< Put additional codes here >-------------------------
    }
  }]);
  return Alert;
}(component);
/* harmony default export */ const src_alert = (Alert);
;// CONCATENATED MODULE: ./src/js/src/util/instances.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): instances.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



var instances = {
  // All component instances.
  all: [],
  // All alert instances.
  alert: [],
  // All collapse instances.
  collapse: [],
  // All dropdown instances.
  dropdown: [],
  // All modal instances.
  modal: [],
  // All offcanvas instances.
  offcanvas: []
};
/* harmony default export */ const util_instances = (instances);
;// CONCATENATED MODULE: ./src/js/src/util/tabs.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): tabs.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



function tabs_createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = tabs_unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function tabs_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return tabs_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return tabs_arrayLikeToArray(o, minLen); }
function tabs_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
var tabs = {
  // Tabbable selector.
  selector: "a, button, input, textarea, select, details, [tabindex], [contenteditable=\"true\"]",
  /**
   * Enable tab on target component.
   * @param {object} component 
   */
  enable: function enable(component) {
    component.element.removeAttribute("tabindex");

    // Remove [tabindex] attribute from tabbable child elements.
    var tabbableChildElements = component.element.querySelectorAll(tabs.selector);
    var _iterator = tabs_createForOfIteratorHelper(tabbableChildElements),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var tabbableChildElement = _step.value;
        // Remove only on child element with parent attribute of [aria-hidden="true"].
        if (tabbableChildElement.closest("[aria-hidden=\"true\"]") === null) tabbableChildElement.removeAttribute("tabindex");
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  },
  /**
   * Disable tab on target componet.
   * @param {object} component 
   */
  disable: function disable(component) {
    console.co;
    component.element.setAttribute("tabindex", -1);
    var tabbableChildElements = component.element.querySelectorAll(tabs.selector);

    // Add [tabindex="-1"] on tabbable child elemenets.
    var _iterator2 = tabs_createForOfIteratorHelper(tabbableChildElements),
      _step2;
    try {
      for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
        var tabbableChildElement = _step2.value;
        tabbableChildElement.setAttribute("tabindex", -1);
      }
    } catch (err) {
      _iterator2.e(err);
    } finally {
      _iterator2.f();
    }
  }
};
/* harmony default export */ const util_tabs = (tabs);
;// CONCATENATED MODULE: ./src/js/src/collapse.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): collapse.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



function collapse_typeof(obj) { "@babel/helpers - typeof"; return collapse_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, collapse_typeof(obj); }
function collapse_createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = collapse_unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function collapse_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return collapse_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return collapse_arrayLikeToArray(o, minLen); }
function collapse_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function collapse_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function collapse_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, collapse_toPropertyKey(descriptor.key), descriptor); } }
function collapse_createClass(Constructor, protoProps, staticProps) { if (protoProps) collapse_defineProperties(Constructor.prototype, protoProps); if (staticProps) collapse_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function collapse_toPropertyKey(arg) { var key = collapse_toPrimitive(arg, "string"); return collapse_typeof(key) === "symbol" ? key : String(key); }
function collapse_toPrimitive(input, hint) { if (collapse_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (collapse_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function collapse_get() { if (typeof Reflect !== "undefined" && Reflect.get) { collapse_get = Reflect.get.bind(); } else { collapse_get = function _get(target, property, receiver) { var base = collapse_superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(arguments.length < 3 ? target : receiver); } return desc.value; }; } return collapse_get.apply(this, arguments); }
function collapse_superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = collapse_getPrototypeOf(object); if (object === null) break; } return object; }
function collapse_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) collapse_setPrototypeOf(subClass, superClass); }
function collapse_setPrototypeOf(o, p) { collapse_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return collapse_setPrototypeOf(o, p); }
function collapse_createSuper(Derived) { var hasNativeReflectConstruct = collapse_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = collapse_getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = collapse_getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return collapse_possibleConstructorReturn(this, result); }; }
function collapse_possibleConstructorReturn(self, call) { if (call && (collapse_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return collapse_assertThisInitialized(self); }
function collapse_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function collapse_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function collapse_getPrototypeOf(o) { collapse_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return collapse_getPrototypeOf(o); }



var Collapse = /*#__PURE__*/function (_Component) {
  collapse_inherits(Collapse, _Component);
  var _super = collapse_createSuper(Collapse);
  /**
   * Collapse constructor.
   * @param {element} element 
   */
  function Collapse(element) {
    var _this;
    collapse_classCallCheck(this, Collapse);
    _this = _super.call(this, element);

    // Element default collapse status.
    _this.isActive = false;

    // Element default collapse accordion id.
    _this.accordionId = null;
    if (_this.element.hasAttribute("data-bc-accordion")) {
      _this.accordionId = _this.element.dataset.bcAccordion;
    }

    // Set default state.
    if (_this.element.getAttribute("aria-hidden") === "false") {
      _this.show();
    } else if (_this.element.getAttribute("aria-hidden") === "true") {
      _this.hide();
    }

    // -------------------------< Put additional codes here >-------------------------
    return _this;
  }

  /**
   * Collapse event handler.
   * @param {event} event 
   */
  collapse_createClass(Collapse, [{
    key: "handleEvent",
    value: function handleEvent(event) {
      collapse_get(collapse_getPrototypeOf(Collapse.prototype), "handleEvent", this).call(this, event);

      // If [data-bc-toggle] attribute is not defined on element with [aria-controls] attribute.
      if (!event.target.hasAttribute("data-bc-toggle")) {
        this.isActive ? this.hide() : this.show();
      }

      // If element have defined [data-bc-accordion] value and is active
      if (this.accordionId !== null && this.isActive) {
        this.toggleAccordion();
      }

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Collapse show handler.
     */
  }, {
    key: "show",
    value: function show() {
      collapse_get(collapse_getPrototypeOf(Collapse.prototype), "show", this).call(this);
      this.isActive = true;
      this.toggle();

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Collapse hide handler.
     */
  }, {
    key: "hide",
    value: function hide() {
      collapse_get(collapse_getPrototypeOf(Collapse.prototype), "hide", this).call(this);
      this.isActive = false;
      this.toggle();

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Collapse toggle handler.
     * 
     * Note: 
     * Value between component element [aria-hidden] and component controls
     * [aria-expanded] must be reversed from each other. This means when
     * [aria-hidden] is "true", [aria-expanded] must be "false".
     */
  }, {
    key: "toggle",
    value: function toggle() {
      collapse_get(collapse_getPrototypeOf(Collapse.prototype), "toggle", this).call(this);

      // Toggle element [aria-hidden] values.
      this.element.setAttribute("aria-hidden", !this.isActive);

      // Toggle contols [aria-expanded] values.
      var _iterator = collapse_createForOfIteratorHelper(this.controls),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var control = _step.value;
          control.setAttribute("aria-expanded", this.isActive);
        }

        // Enable/Disable tabs on element based on active state.
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      this.isActive ? util_tabs.enable(this) : util_tabs.disable(this);

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Toggle accordion.
     */
  }, {
    key: "toggleAccordion",
    value: function toggleAccordion() {
      // Close other collapses with same [data-accordion] value.
      var _iterator2 = collapse_createForOfIteratorHelper(util_instances.collapse),
        _step2;
      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          var instance = _step2.value;
          if (instance.accordionId === this.accordionId && instance.id != this.id) instance.hide();
        }

        // -------------------------< Put additional codes here >-------------------------
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
    }
  }]);
  return Collapse;
}(component);
/* harmony default export */ const collapse = (Collapse);
;// CONCATENATED MODULE: ./src/js/src/dropdown.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): dropdown.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



function dropdown_typeof(obj) { "@babel/helpers - typeof"; return dropdown_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, dropdown_typeof(obj); }
function dropdown_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function dropdown_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, dropdown_toPropertyKey(descriptor.key), descriptor); } }
function dropdown_createClass(Constructor, protoProps, staticProps) { if (protoProps) dropdown_defineProperties(Constructor.prototype, protoProps); if (staticProps) dropdown_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function dropdown_toPropertyKey(arg) { var key = dropdown_toPrimitive(arg, "string"); return dropdown_typeof(key) === "symbol" ? key : String(key); }
function dropdown_toPrimitive(input, hint) { if (dropdown_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (dropdown_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function dropdown_get() { if (typeof Reflect !== "undefined" && Reflect.get) { dropdown_get = Reflect.get.bind(); } else { dropdown_get = function _get(target, property, receiver) { var base = dropdown_superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(arguments.length < 3 ? target : receiver); } return desc.value; }; } return dropdown_get.apply(this, arguments); }
function dropdown_superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = dropdown_getPrototypeOf(object); if (object === null) break; } return object; }
function dropdown_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) dropdown_setPrototypeOf(subClass, superClass); }
function dropdown_setPrototypeOf(o, p) { dropdown_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return dropdown_setPrototypeOf(o, p); }
function dropdown_createSuper(Derived) { var hasNativeReflectConstruct = dropdown_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = dropdown_getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = dropdown_getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return dropdown_possibleConstructorReturn(this, result); }; }
function dropdown_possibleConstructorReturn(self, call) { if (call && (dropdown_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return dropdown_assertThisInitialized(self); }
function dropdown_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function dropdown_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function dropdown_getPrototypeOf(o) { dropdown_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return dropdown_getPrototypeOf(o); }


var Dropdown = /*#__PURE__*/function (_Component) {
  dropdown_inherits(Dropdown, _Component);
  var _super = dropdown_createSuper(Dropdown);
  /**
   * Dropdown constructor.
   * @param {element} element 
   */
  function Dropdown(element) {
    var _this;
    dropdown_classCallCheck(this, Dropdown);
    _this = _super.call(this, element);

    // Element default state.
    _this.isActive = false;

    // Triggers "this.hide()" by default.
    _this.hide();

    // Handle click outside.
    window.addEventListener("click", _this.toggleClickOutside(dropdown_assertThisInitialized(_this)));

    // Handle click outside for touch based screen.
    window.addEventListener("touchstart", _this.toggleClickOutside(dropdown_assertThisInitialized(_this)));

    // -------------------------< Put additional codes here >-------------------------
    return _this;
  }

  /**
   * Dropdown event handler.
   * @param {object} event 
   */
  dropdown_createClass(Dropdown, [{
    key: "handleEvent",
    value: function handleEvent(event) {
      dropdown_get(dropdown_getPrototypeOf(Dropdown.prototype), "handleEvent", this).call(this, event);

      // If [data-bc-toggle] attribute is not defined on element with [aria-controls] attribute.
      if (event.target.hasAttribute("data-bc-toggle") === false) {
        this.isActive ? this.hide() : this.show();
      }

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Dropdown show handler.
     */
  }, {
    key: "show",
    value: function show() {
      dropdown_get(dropdown_getPrototypeOf(Dropdown.prototype), "show", this).call(this);
      this.isActive = true;
      this.toggle();

      // -------------------------< Put additional codes here >-------------------------
      this.element.classList.add('active');
    }

    /**
     * Dropdown hide handler.
     */
  }, {
    key: "hide",
    value: function hide() {
      dropdown_get(dropdown_getPrototypeOf(Dropdown.prototype), "hide", this).call(this);
      this.isActive = false;
      this.toggle();

      // -------------------------< Put additional codes here >-------------------------
      this.element.classList.remove('active');
    }

    /**
     * Dropdown toggle handler.
     */
  }, {
    key: "toggle",
    value: function toggle() {
      dropdown_get(dropdown_getPrototypeOf(Dropdown.prototype), "toggle", this).call(this);

      // Toggle element [aria-hidden] value.
      this.element.setAttribute("aria-hidden", !this.isActive);

      // Enable/Disable tabs on element based on active state.
      this.isActive ? util_tabs.enable(this) : util_tabs.disable(this);

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Dropdown toggle click outside handler.
     * @param {object} component 
     * @returns {event}
     */
  }, {
    key: "toggleClickOutside",
    value: function toggleClickOutside(component) {
      return function (event) {
        var targetComponent = event.target.closest("[data-bc-id=\"".concat(component.id, "\"]"));
        var targetAriaControls = event.target.closest("[aria-controls=\"".concat(component.id, "\"]"));
        if (targetComponent === null && targetAriaControls === null) component.hide();

        // -------------------------< Put additional codes here >-------------------------
      };
    }
  }]);
  return Dropdown;
}(component);
/* harmony default export */ const dropdown = (Dropdown);
;// CONCATENATED MODULE: ./src/js/src/util/document-scroll.js
/**
* --------------------------------------------------------------------------
* Base Component JS (v0.2.0): document-scroll.js
* Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
* --------------------------------------------------------------------------
*/



var documentScroll = {
  enable: function enable() {
    document.documentElement.style.overflow = 'auto';
  },
  disable: function disable() {
    document.documentElement.style.overflow = 'hidden';
  }
};
/* harmony default export */ const document_scroll = (documentScroll);
;// CONCATENATED MODULE: ./src/js/src/util/focus-trap.js
/**
* --------------------------------------------------------------------------
* Base Component JS (v0.2.0): focus-trap.js
* Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
* --------------------------------------------------------------------------
*/



var focusTrap = {
  // Focus trap selector.
  selector: "a:not([tabindex=\"-1\"]), button:not([tabindex=\"-1\"]), input:not([tabindex=\"-1\"]), textarea:not([tabindex=\"-1\"]), select:not([tabindex=\"-1\"]), details:not([tabindex=\"-1\"]), [tabindex]:not([tabindex=\"-1\"]), [contenteditable=\"true\"]:not([tabindex=\"-1\"])",
  // Current active focus trap.
  current: null,
  /**
   * Enable focus trap on target component.
   * @param {object} component 
   */
  enable: function enable(component) {
    if (focusTrap.current !== null) focusTrap.current.hide();
    focusTrap.current = component;
    window.addEventListener("keydown", focusTrap.handler);

    // Set focus on "focusTrap.current" to force focus.
    setTimeout(function () {
      focusTrap.current.element.setAttribute("tabindex", 0);
      focusTrap.current.element.focus();
    }, 50);

    // Remove focus on "ocusTrap.current" for smooth focus trap.
    setTimeout(function () {
      focusTrap.current.element.removeAttribute("tabindex");
      focusTrap.current.element.blur();
    }, 100);
  },
  /**
   * Disable focus trap.
   */
  disable: function disable() {
    focusTrap.current = null;
    window.removeEventListener("keydown", focusTrap.handler);
  },
  /**
   * Focus trap handler.
   * @param {event} event 
   * @returns 
   */
  handler: function handler(event) {
    if (focusTrap.current == null) return;
    var focusableElements = focusTrap.current.element.querySelectorAll(focusTrap.selector);
    var firstElement = focusableElements[0];
    var lastElement = focusableElements[focusableElements.length - 1];
    if (event.type === "keydown" && event.keyCode === 9) {
      if (event.shiftKey && (document.activeElement === firstElement || document.activeElement === document.body)) {
        event.preventDefault();
        lastElement.focus();
      } else if (!event.shiftKey && document.activeElement === lastElement) {
        event.preventDefault();
        firstElement.focus();
      }
    }
  }
};
/* harmony default export */ const focus_trap = (focusTrap);
;// CONCATENATED MODULE: ./src/js/src/modal.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): modal.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



function modal_typeof(obj) { "@babel/helpers - typeof"; return modal_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, modal_typeof(obj); }
function modal_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function modal_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, modal_toPropertyKey(descriptor.key), descriptor); } }
function modal_createClass(Constructor, protoProps, staticProps) { if (protoProps) modal_defineProperties(Constructor.prototype, protoProps); if (staticProps) modal_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function modal_toPropertyKey(arg) { var key = modal_toPrimitive(arg, "string"); return modal_typeof(key) === "symbol" ? key : String(key); }
function modal_toPrimitive(input, hint) { if (modal_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (modal_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function modal_get() { if (typeof Reflect !== "undefined" && Reflect.get) { modal_get = Reflect.get.bind(); } else { modal_get = function _get(target, property, receiver) { var base = modal_superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(arguments.length < 3 ? target : receiver); } return desc.value; }; } return modal_get.apply(this, arguments); }
function modal_superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = modal_getPrototypeOf(object); if (object === null) break; } return object; }
function modal_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) modal_setPrototypeOf(subClass, superClass); }
function modal_setPrototypeOf(o, p) { modal_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return modal_setPrototypeOf(o, p); }
function modal_createSuper(Derived) { var hasNativeReflectConstruct = modal_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = modal_getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = modal_getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return modal_possibleConstructorReturn(this, result); }; }
function modal_possibleConstructorReturn(self, call) { if (call && (modal_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return modal_assertThisInitialized(self); }
function modal_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function modal_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function modal_getPrototypeOf(o) { modal_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return modal_getPrototypeOf(o); }




var Modal = /*#__PURE__*/function (_Component) {
  modal_inherits(Modal, _Component);
  var _super = modal_createSuper(Modal);
  /**
   * Modal constructor.
   * @param {element} element 
   */
  function Modal(element) {
    var _this;
    modal_classCallCheck(this, Modal);
    _this = _super.call(this, element);

    // Element default focus trap mode.
    _this.isFocustrap = true;

    // Element default scrollable state.
    _this.isScrollable = true;

    // If modal mode is scrollable.
    if (_this.element.hasAttribute("data-bc-scrollable")) _this.isScrollable = _this.element.dataset.scrollable === 'true';

    // Set default state.
    _this.element.getAttribute("aria-hidden") === "false" ? _this.show() : _this.hide();

    // -------------------------< Put additional codes here >-------------------------
    return _this;
  }

  /**
   * Modal event handler.
   * @param {object} event 
   */
  modal_createClass(Modal, [{
    key: "handleEvent",
    value: function handleEvent(event) {
      modal_get(modal_getPrototypeOf(Modal.prototype), "handleEvent", this).call(this, event);

      // If [data-bc-toggle] attribute is not defined on element with [aria-controls] attribute.
      if (!event.target.hasAttribute("data-bc-toggle")) {
        this.isActive ? this.hide() : this.show();
      }

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Modal show handler.
     */
  }, {
    key: "show",
    value: function show() {
      modal_get(modal_getPrototypeOf(Modal.prototype), "show", this).call(this);
      this.isActive = true;
      this.toggle();

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Modal hide handler.
     */
  }, {
    key: "hide",
    value: function hide() {
      modal_get(modal_getPrototypeOf(Modal.prototype), "hide", this).call(this);
      this.isActive = false;
      this.toggle();

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Modal toggle handler.
     */
  }, {
    key: "toggle",
    value: function toggle() {
      // Toggle attribute values.
      this.element.setAttribute("aria-hidden", !this.isActive);

      // Enable/Disable tabs and focus trap on element.
      if (this.isActive) {
        util_tabs.enable(this);
        focus_trap.enable(this);

        // If modal mode is non scrollable
        if (!this.isScrollable) document_scroll.disable();
      } else {
        util_tabs.disable(this);
        focus_trap.disable();
        document_scroll.enable();
      }
      // -------------------------< Put additional codes here >-------------------------
    }
  }]);
  return Modal;
}(component);
/* harmony default export */ const modal = (Modal);
;// CONCATENATED MODULE: ./src/js/src/offcanvas.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): offcanvas.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



function offcanvas_typeof(obj) { "@babel/helpers - typeof"; return offcanvas_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, offcanvas_typeof(obj); }
function offcanvas_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function offcanvas_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, offcanvas_toPropertyKey(descriptor.key), descriptor); } }
function offcanvas_createClass(Constructor, protoProps, staticProps) { if (protoProps) offcanvas_defineProperties(Constructor.prototype, protoProps); if (staticProps) offcanvas_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function offcanvas_toPropertyKey(arg) { var key = offcanvas_toPrimitive(arg, "string"); return offcanvas_typeof(key) === "symbol" ? key : String(key); }
function offcanvas_toPrimitive(input, hint) { if (offcanvas_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (offcanvas_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function offcanvas_get() { if (typeof Reflect !== "undefined" && Reflect.get) { offcanvas_get = Reflect.get.bind(); } else { offcanvas_get = function _get(target, property, receiver) { var base = offcanvas_superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(arguments.length < 3 ? target : receiver); } return desc.value; }; } return offcanvas_get.apply(this, arguments); }
function offcanvas_superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = offcanvas_getPrototypeOf(object); if (object === null) break; } return object; }
function offcanvas_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) offcanvas_setPrototypeOf(subClass, superClass); }
function offcanvas_setPrototypeOf(o, p) { offcanvas_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return offcanvas_setPrototypeOf(o, p); }
function offcanvas_createSuper(Derived) { var hasNativeReflectConstruct = offcanvas_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = offcanvas_getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = offcanvas_getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return offcanvas_possibleConstructorReturn(this, result); }; }
function offcanvas_possibleConstructorReturn(self, call) { if (call && (offcanvas_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return offcanvas_assertThisInitialized(self); }
function offcanvas_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function offcanvas_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function offcanvas_getPrototypeOf(o) { offcanvas_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return offcanvas_getPrototypeOf(o); }





var Offcanvas = /*#__PURE__*/function (_Component) {
  offcanvas_inherits(Offcanvas, _Component);
  var _super = offcanvas_createSuper(Offcanvas);
  /**
   * Offcanvas constructor.
   * @param {element} element 
   */
  function Offcanvas(element) {
    var _this;
    offcanvas_classCallCheck(this, Offcanvas);
    _this = _super.call(this, element);

    // Element default focus trap mode.
    _this.isFocustrap = true;

    // Element default scrollable state.
    _this.isScrollable = true;

    // If offcanvas mode is scrollable.
    if (_this.element.hasAttribute("data-bc-scrollable")) _this.isScrollable = _this.element.dataset.scrollable === 'true';

    // Set default state.
    _this.element.getAttribute("aria-hidden") === "false" ? _this.show() : _this.hide();

    // -------------------------< Put additional codes here >-------------------------
    return _this;
  }

  /**
   * Offcanvas event handler.
   * @param {object} event 
   */
  offcanvas_createClass(Offcanvas, [{
    key: "handleEvent",
    value: function handleEvent(event) {
      offcanvas_get(offcanvas_getPrototypeOf(Offcanvas.prototype), "handleEvent", this).call(this, event);

      // If [data-bc-toggle] attribute is not defined on element with [aria-controls] attribute.
      if (!event.target.hasAttribute("data-bc-toggle")) {
        this.isActive ? this.hide() : this.show();
      }

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Offcanvas show handler.
     */
  }, {
    key: "show",
    value: function show() {
      offcanvas_get(offcanvas_getPrototypeOf(Offcanvas.prototype), "show", this).call(this);
      this.isActive = true;
      this.toggle();

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Offcanvas hide handler.
     */
  }, {
    key: "hide",
    value: function hide() {
      offcanvas_get(offcanvas_getPrototypeOf(Offcanvas.prototype), "hide", this).call(this);
      this.isActive = false;
      this.toggle();

      // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Offcanvas toggle handler.
     */
  }, {
    key: "toggle",
    value: function toggle() {
      // Toggle attribute values.
      this.element.setAttribute("aria-hidden", !this.isActive);

      // Enable/Disable tabs and focus trap on element.
      if (this.isActive) {
        util_tabs.enable(this);
        focus_trap.enable(this);

        // If modal mode is non scrollable
        if (!this.isScrollable) document_scroll.disable();
      } else {
        util_tabs.disable(this);
        focus_trap.disable();
        document_scroll.enable();
      }
      // -------------------------< Put additional codes here >-------------------------
    }
  }]);
  return Offcanvas;
}(component);
/* harmony default export */ const offcanvas = (Offcanvas);
;// CONCATENATED MODULE: ./src/js/src/util/validate.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): validate.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



function validate_createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = validate_unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function validate_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return validate_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return validate_arrayLikeToArray(o, minLen); }
function validate_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

var validate = {
  /**
   * Validate element as a valid component.
   * @param {element} element 
   * @returns {boolean}
   */
  component: function component(element) {
    var isIdValid = validate.id(element);
    var isTypeValid = validate.type(element);
    var isUnique = validate.instances(element);
    if (isIdValid && isTypeValid && isUnique) return true;
    return false;
  },
  /**
   * Validate element [id] attributes exists and not null.
   * @param {element} element 
   * @returns {boolean}
   */
  id: function id(element) {
    var id = element.getAttribute("id");
    if (document.querySelectorAll("[data-bc-id=".concat(id, "]")).length > 1) return false;
    if (id === null || id === "") return false;
    return true;
  },
  /**
   * Validate element [data-bc] attributes not null.
   * @param {element} element 
   * @returns {boolean}
   */
  type: function type(element) {
    var type = element.dataset.bc;
    if (type === "") return false;
    return true;
  },
  instances: function instances(element) {
    var _iterator = validate_createForOfIteratorHelper(util_instances.all),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var instance = _step.value;
        if (element === instance.element) return false;
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    return true;
  }
};
/* harmony default export */ const util_validate = (validate);
;// CONCATENATED MODULE: ./src/js/base-component.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0) base-component.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



function base_component_createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = base_component_unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function base_component_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return base_component_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return base_component_arrayLikeToArray(o, minLen); }
function base_component_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }







var baseComponentJs = {
  /**
   * Initilize.
   */
  init: function init() {
    var components = document.querySelectorAll("[data-bc]");
    var _iterator = base_component_createForOfIteratorHelper(components),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var element = _step.value;
        if (util_validate.component(element) === false) continue;
        var type = element.dataset.bc;
        switch (type) {
          case "alert":
            util_instances.all.push(new src_alert(element));
            util_instances.alert.push(util_instances.all[util_instances.all.length - 1]);
            break;
          case "collapse":
            util_instances.all.push(new collapse(element));
            util_instances.collapse.push(util_instances.all[util_instances.all.length - 1]);
            break;
          case "dropdown":
            util_instances.all.push(new dropdown(element));
            util_instances.dropdown.push(util_instances.all[util_instances.all.length - 1]);
            break;
          case "modal":
            util_instances.all.push(new modal(element));
            util_instances.modal.push(util_instances.all[util_instances.all.length - 1]);
            break;
          case "offcanvas":
            util_instances.all.push(new offcanvas(element));
            util_instances.modal.push(util_instances.all[util_instances.all.length - 1]);
            break;
          default:
            break;
        }
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  },
  /**
   * Get component object.
   * @param {string} id 
   * @returns {instance}
   */
  $: function $(id) {
    var _iterator2 = base_component_createForOfIteratorHelper(util_instances.all),
      _step2;
    try {
      for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
        var instance = _step2.value;
        if (instance.id === id) return instance;
      }
    } catch (err) {
      _iterator2.e(err);
    } finally {
      _iterator2.f();
    }
  }
};

/**
 * Execute when document DOM is loaded to make sure all elements have been
 * completely rendered.
 */
document.addEventListener("DOMContentLoaded", function () {
  baseComponentJs.init();

  // Handle scenario when element is created after "DomContentLoaded" event
  // to register new component.
  document.body.addEventListener('DOMNodeInserted', function () {
    baseComponentJs.init();
  });
});
/* harmony default export */ const base_component = (baseComponentJs);
;// CONCATENATED MODULE: ./src/index.js


// Pass "baseComponentJs" to be used as a global object.
window.baseComponentJs = base_component;
/******/ })()
;