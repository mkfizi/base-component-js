/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./src/js/src/component.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): component.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



class Component {
    /**
     * Component constructor
     * @param {element} element 
     */
    constructor(element) {
        // Component [id] value.
        this.element = element; 

        // Component element element.
        this.id = this.element.getAttribute("id");

        // Element with [aria-controls] to trigger component event.  
        this.controls = document.querySelectorAll(`[aria-controls="${this.id}"]`);
        
        for (let control of this.controls) {
            control.addEventListener("click", this);
        }

        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Component event handler.
     * @param {object} event 
     */
    handleEvent(event) {
        if (event.target.hasAttribute("data-bc-toggle")) {
            if (event.target.getAttribute("data-bc-toggle") === "show") {
                this.show();
            } else if (event.target.getAttribute("data-bc-toggle") === "hide") {
                this.hide();
            }
        }
    
        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Component show handler.
     */
    show() {
        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Component hide handler.
     */
    hide() {
        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Component toggle handler.
     */
    toggle() {
        // -------------------------< Put additional codes here >-------------------------
    }
}

/* harmony default export */ const component = (Component);
;// CONCATENATED MODULE: ./src/js/src/alert.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): alert.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */





class Alert extends component {
    /**
     * Alert constructor.
     * @param {element} element 
     */
    constructor(element) {
        super(element);

       // -------------------------< Put additional codes here >-------------------------
       // Element's parent element.
       this.parentElement = this.element.parentElement;
    }

    /**
     * Alert event handler.
     * @param {object} event 
     */
    handleEvent(event) {
        super.handleEvent(event);
        
        // If [data-bc-toggle] attribute is not defined on element with [aria-controls] attribute.
        if (!event.target.hasAttribute("data-bc-toggle")) this.hide();

        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Alert hide handler.
     */
    hide() {
        super.hide();

        this.element.remove();

        // -------------------------< Put additional codes here >-------------------------
        
        // create notification text.
        let notificationText = document.createElement("p");
        notificationText.innerHTML = "Alert container has been removed.";

        // Create reset button.
        let resetButton = document.createElement("button");
        resetButton.setAttribute("type", "button");
        resetButton.innerHTML = "Reset";

        // Add "click" event on reset button which will reset view.
        resetButton.addEventListener("click", () => {
            notificationText.remove();
            resetButton.remove();
            this.parentElement.appendChild(this.element)
        })

        // Append notification and reload page button in document body.
        this.parentElement.appendChild(notificationText);
        this.parentElement.appendChild(resetButton);
    }
}

/* harmony default export */ const src_alert = (Alert);
;// CONCATENATED MODULE: ./src/js/src/util/instances.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): instances.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



const instances = {
    // All component instances.
    all: [],

    // All alert instances.
    alert: [],

    // All collapse instances.
    collapse: [],
    
    // All dropdown instances.
    dropdown: [],
    
    // All modal instances.
    modal: [],
    
    // All offcanvas instances.
    offcanvas: [],
}

/* harmony default export */ const util_instances = (instances);
;// CONCATENATED MODULE: ./src/js/src/util/tabs.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): tabs.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */



const tabs = {
    // Tabbable selector.
    selector: `a, button, input, textarea, select, details, [tabindex], [contenteditable="true"]`,

    /**
     * Enable tab on target component.
     * @param {object} component 
     */
    enable: component => {
        component.element.removeAttribute("tabindex");

        // Remove [tabindex] attribute from tabbable child elements.
        let tabbableChildElements = component.element.querySelectorAll(tabs.selector);
        for (let tabbableChildElement of tabbableChildElements) {

            // Remove only on child element with parent attribute of [aria-hidden="true"].
            if (tabbableChildElement.closest(`[aria-hidden="true"]`) === null) tabbableChildElement.removeAttribute("tabindex");
        }
    },
    /**
     * Disable tab on target componet.
     * @param {object} component 
     */
    disable: component => {
        console.co
        component.element.setAttribute("tabindex", -1);

        let tabbableChildElements = component.element.querySelectorAll(tabs.selector);

        // Add [tabindex="-1"] on tabbable child elemenets.
        for (let tabbableChildElement of tabbableChildElements) {
            tabbableChildElement.setAttribute("tabindex", -1);
        }
    }
}

/* harmony default export */ const util_tabs = (tabs);
;// CONCATENATED MODULE: ./src/js/src/collapse.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): collapse.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */

 






class Collapse extends component {
    /**
     * Collapse constructor.
     * @param {element} element 
     */
    constructor(element) {
        super(element);

        // Element default collapse status.
        this.isActive = false

        // Element default collapse accordion id.
        this.accordionId = null;

        if (this.element.hasAttribute("data-bc-accordion")) {
            this.accordionId = this.element.dataset.bcAccordion;
        }

        // Set default state.
        if (this.element.getAttribute("aria-hidden") === "false") {
            this.show();
        } else if (this.element.getAttribute("aria-hidden") === "true"){
            this.hide();
        }

        // -------------------------< Put additional codes here >-------------------------
    }
    
    /**
     * Collapse event handler.
     * @param {event} event 
     */
    handleEvent(event) {
        super.handleEvent(event);

        // If [data-bc-toggle] attribute is not defined on element with [aria-controls] attribute.
        if (!event.target.hasAttribute("data-bc-toggle")) {
            this.isActive
                ? this.hide()
                : this.show();
        }

        // If element have defined [data-bc-accordion] value and is active
        if (this.accordionId !== null && this.isActive) {
            this.toggleAccordion();
        }

        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Collapse show handler.
     */
    show() {
        super.show();

        this.isActive = true;
        this.toggle();

        // -------------------------< Put additional codes here >-------------------------
        this.element.classList.add('active');
    }

    /**
     * Collapse hide handler.
     */
    hide() {
        super.hide();

        this.isActive = false;
        this.toggle()

        // -------------------------< Put additional codes here >-------------------------
        this.element.classList.remove('active');
    }
    
    /**
     * Collapse toggle handler.
     * 
     * Note: 
     * Value between component element [aria-hidden] and component controls
     * [aria-expanded] must be reversed from each other. This means when
     * [aria-hidden] is "true", [aria-expanded] must be "false".
     */
    toggle() {
        super.toggle();

        // Toggle element [aria-hidden] values.
        this.element.setAttribute("aria-hidden", !this.isActive);
        
        // Toggle contols [aria-expanded] values.
        for (let control of this.controls) {
            control.setAttribute("aria-expanded", this.isActive);
        }

        // Enable/Disable tabs on element based on active state.
        this.isActive
            ? util_tabs.enable(this)
            : util_tabs.disable(this);
        
        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Toggle accordion.
     */
    toggleAccordion() {
        // Close other collapses with same [data-accordion] value.
        for (let instance of util_instances.collapse) {
            if (instance.accordionId === this.accordionId && instance.id != this.id) instance.hide();
        }

        // -------------------------< Put additional codes here >-------------------------
    }
}

/* harmony default export */ const collapse = (Collapse);
;// CONCATENATED MODULE: ./src/js/src/dropdown.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): dropdown.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */







class Dropdown extends component {
    /**
     * Dropdown constructor.
     * @param {element} element 
     */
    constructor(element) {
        super(element);

        // Element default state.
        this.isActive = false;

        // Triggers "this.hide()" by default.
        this.hide();

        // Handle click outside.
        window.addEventListener("click", this.toggleClickOutside(this));

        // Handle click outside for touch based screen.
        window.addEventListener("touchstart", this.toggleClickOutside(this));

        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Dropdown event handler.
     * @param {object} event 
     */
    handleEvent(event) {
        super.handleEvent(event);
        
        // If [data-bc-toggle] attribute is not defined on element with [aria-controls] attribute.
        if (event.target.hasAttribute("data-bc-toggle") === false) {
            this.isActive
                ? this.hide()
                : this.show();
        }

        // -------------------------< Put additional codes here >-------------------------
    }
    
    /**
     * Dropdown show handler.
     */
    show() {
        super.show();

        this.isActive = true; 
        this.toggle();

        // -------------------------< Put additional codes here >-------------------------
        this.element.classList.add('active');
    }

    /**
     * Dropdown hide handler.
     */
    hide() {
        super.hide();

        this.isActive = false; 
        this.toggle();

        // -------------------------< Put additional codes here >-------------------------
        this.element.classList.remove('active');
    }

    /**
     * Dropdown toggle handler.
     */
    toggle() {
        super.toggle();

        // Toggle element [aria-hidden] value.
        this.element.setAttribute("aria-hidden", !this.isActive);    
        
        // Enable/Disable tabs on element based on active state.
        this.isActive
            ? util_tabs.enable(this)
            : util_tabs.disable(this);
        
        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Dropdown toggle click outside handler.
     * @param {object} component 
     * @returns {event}
     */
    toggleClickOutside(component) {
        return event => {
            let targetComponent = event.target.closest(`[data-bc-id="${component.id}"]`);
            let targetAriaControls = event.target.closest(`[aria-controls="${component.id}"]`);

            if (targetComponent === null && targetAriaControls === null ) component.hide();

            // -------------------------< Put additional codes here >-------------------------
        }
    }
}

/* harmony default export */ const dropdown = (Dropdown);
;// CONCATENATED MODULE: ./src/js/src/util/document-scroll.js
/**
* --------------------------------------------------------------------------
* Base Component JS (v0.2.0): document-scroll.js
* Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
* --------------------------------------------------------------------------
*/



const documentScroll = {
    enable: () => {
        document.documentElement.style.overflow = 'auto';
    },
    disable: () => {
        document.documentElement.style.overflow = 'hidden';
    }
}

/* harmony default export */ const document_scroll = (documentScroll);
;// CONCATENATED MODULE: ./src/js/src/util/focus-trap.js
/**
* --------------------------------------------------------------------------
* Base Component JS (v0.2.0): focus-trap.js
* Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
* --------------------------------------------------------------------------
*/



const focusTrap = {
    // Focus trap selector.
    selector: `a:not([tabindex="-1"]), button:not([tabindex="-1"]), input:not([tabindex="-1"]), textarea:not([tabindex="-1"]), select:not([tabindex="-1"]), details:not([tabindex="-1"]), [tabindex]:not([tabindex="-1"]), [contenteditable="true"]:not([tabindex="-1"])`,

    // Current active focus trap.
    current: null,

    /**
     * Enable focus trap on target component.
     * @param {object} component 
     */
    enable: component => {
        if(focusTrap.current !== null) focusTrap.current.hide();
        focusTrap.current = component;

        window.addEventListener("keydown", focusTrap.handler);
    
        // Set focus on "focusTrap.current" to force focus.
        setTimeout(() => { 
            focusTrap.current.element.setAttribute("tabindex", 0);
            focusTrap.current.element.focus();
        }, 50);

        // Remove focus on "ocusTrap.current" for smooth focus trap.
        setTimeout(() => { 
            focusTrap.current.element.removeAttribute("tabindex"); 
            focusTrap.current.element.blur();
        }, 100);
    },

    /**
     * Disable focus trap.
     */
    disable: () => {
        focusTrap.current = null;
        window.removeEventListener("keydown", focusTrap.handler);
    },

    /**
     * Focus trap handler.
     * @param {event} event 
     * @returns 
     */
    handler: event => {
        if (focusTrap.current == null) return;

        let focusableElements = focusTrap.current.element.querySelectorAll(focusTrap.selector);
        
        let firstElement = focusableElements[0];
        let lastElement = focusableElements[focusableElements.length - 1];
    
        if (event.type === "keydown" && event.keyCode === 9) {
            if (event.shiftKey && (document.activeElement === firstElement || document.activeElement === document.body)) {
                event.preventDefault();
                lastElement.focus();
            } else if (!event.shiftKey && document.activeElement === lastElement) {
                event.preventDefault();
                firstElement.focus();
            }
        }
    }
}

/* harmony default export */ const focus_trap = (focusTrap);

;// CONCATENATED MODULE: ./src/js/src/modal.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): modal.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */









class Modal extends component {
    /**
     * Modal constructor.
     * @param {element} element 
     */
    constructor(element) {
        super(element);

        // Element default focus trap mode.
        this.isFocustrap = true;

        // Element default scrollable state.
        this.isScrollable = true;

        // If modal mode is scrollable.
        if (this.element.hasAttribute("data-bc-scrollable")) this.isScrollable = (this.element.dataset.scrollable === 'true');

        // Set default state.
        this.element.getAttribute("aria-hidden") === "false"
            ? this.show()
            : this.hide();
        
        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Modal event handler.
     * @param {object} event 
     */
    handleEvent(event) {
        super.handleEvent(event);
        
        // If [data-bc-toggle] attribute is not defined on element with [aria-controls] attribute.
        if (!event.target.hasAttribute("data-bc-toggle")) {
            this.isActive
                ? this.hide()
                : this.show();
        }
        
        // -------------------------< Put additional codes here >-------------------------
    }
    
    /**
     * Modal show handler.
     */
    show() {
        super.show();

        this.isActive = true;
        this.toggle();

        // -------------------------< Put additional codes here >-------------------------
        this.element.classList.add('active');

        // Display modal content and uses "timeout()" for smoother animations.
        let content = this.element.querySelector(".modal-content");
        if (content !== null) setTimeout(() => content.classList.add('active'), 50);
    }

    /**
     * Modal hide handler.
     */
    hide() {
        super.hide();

        this.isActive = false;

        this.toggle();

        // -------------------------< Put additional codes here >-------------------------
        let content = this.element.querySelector(".modal-content");
        if (content != null) content.classList.remove('active');
        
        this.element.classList.remove('active');
    }

    /**
     * Modal toggle handler.
     */
    toggle() {
        // Toggle attribute values.
        this.element.setAttribute("aria-hidden", !this.isActive);

        // Enable/Disable tabs and focus trap on element.
        if (this.isActive) {
            util_tabs.enable(this)
            focus_trap.enable(this);

            // If modal mode is non scrollable
            if (!this.isScrollable) document_scroll.disable();
        } else {
            util_tabs.disable(this);
            focus_trap.disable();
            document_scroll.enable();
        }
        // -------------------------< Put additional codes here >-------------------------
    }
}

/* harmony default export */ const modal = (Modal);
;// CONCATENATED MODULE: ./src/js/src/offcanvas.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): offcanvas.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */










class Offcanvas extends component {
    /**
     * Offcanvas constructor.
     * @param {element} element 
     */
    constructor(element) {
        super(element);

        // Element default focus trap mode.
        this.isFocustrap = true;

        // Element default scrollable state.
        this.isScrollable = true;

        // If offcanvas mode is scrollable.
        if (this.element.hasAttribute("data-bc-scrollable")) this.isScrollable = (this.element.dataset.scrollable === 'true');


        // Set default state.
        this.element.getAttribute("aria-hidden") === "false"
            ? this.show()
            : this.hide();

        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Offcanvas event handler.
     * @param {object} event 
     */
    handleEvent(event) {
        super.handleEvent(event);
        
        // If [data-bc-toggle] attribute is not defined on element with [aria-controls] attribute.
        if (!event.target.hasAttribute("data-bc-toggle")) {
            this.isActive
                ? this.hide()
                : this.show();
        }

        // -------------------------< Put additional codes here >-------------------------
    }

    /**
     * Offcanvas show handler.
     */
    show() {
        super.show();

        this.isActive = true;
        this.toggle();

        // -------------------------< Put additional codes here >-------------------------
        this.element.classList.add('active');

        // Display offcanvas content and uses "timeout()" for smoother animations.
        let content = this.element.querySelector(".offcanvas-content");
        if (content !== null) setTimeout(() => content.classList.add('active'), 50);
    }

    /**
     * Offcanvas hide handler.
     */
    hide() {
        super.hide();

        this.isActive = false;
        this.toggle();

        // -------------------------< Put additional codes here >-------------------------
        let content = this.element.querySelector(".offcanvas-content");
        if (content !== null) content.classList.remove('active');

        this.element.classList.remove('active');
    }

    /**
     * Offcanvas toggle handler.
     */
     toggle() {
        // Toggle attribute values.
        this.element.setAttribute("aria-hidden", !this.isActive);

        // Enable/Disable tabs and focus trap on element.
        if (this.isActive) {
            util_tabs.enable(this)
            focus_trap.enable(this);

            // If modal mode is non scrollable
            if (!this.isScrollable) document_scroll.disable();
        } else {
            util_tabs.disable(this);
            focus_trap.disable();
            document_scroll.enable();
        }
        // -------------------------< Put additional codes here >-------------------------
    }
}

/* harmony default export */ const offcanvas = (Offcanvas);
;// CONCATENATED MODULE: ./src/js/src/util/validate.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0): validate.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */





const validate = {
    /**
     * Validate element as a valid component.
     * @param {element} element 
     * @returns {boolean}
     */
    component : element => {
        let isIdValid = validate.id(element);
        let isTypeValid = validate.type(element);
        let isUnique = validate.instances(element);

        if (isIdValid && isTypeValid && isUnique) return true;
        
        return false;
    },

    /**
     * Validate element [id] attributes exists and not null.
     * @param {element} element 
     * @returns {boolean}
     */
    id: element => {
        let id = element.getAttribute("id");

        if (document.querySelectorAll(`[data-bc-id=${id}]`).length > 1) return false;

        if (id === null || id === "") return false;

        return true;
    },
    
    /**
     * Validate element [data-bc] attributes not null.
     * @param {element} element 
     * @returns {boolean}
     */
    type: element => {
        let type = element.dataset.bc;

        if (type === "") return false;

        return true;
    },

    instances: element => {
        for (let instance of util_instances.all) {
            if (element === instance.element) return false;
        }

        return true;
    }
}

/* harmony default export */ const util_validate = (validate);
;// CONCATENATED MODULE: ./src/js/base-component.js
/**
 * --------------------------------------------------------------------------
 * Base Component JS (v0.2.0) base-component.js
 * Licensed under MIT (https://github.com/mkfizi/base-component-js/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */












const baseComponentJs = {
    /**
     * Initilize.
     */
    init: () => {
        let components = document.querySelectorAll("[data-bc]");
        for (let element of components) {
            if (util_validate.component(element) === false) continue;

            let type = element.dataset.bc;

            switch (type) {
                case "alert":
                    util_instances.all.push(new src_alert(element));
                    util_instances.alert.push(util_instances.all[util_instances.all.length - 1]);
                    break;

                case "collapse":
                    util_instances.all.push(new collapse(element));
                    util_instances.collapse.push(util_instances.all[util_instances.all.length - 1]);
                    break;

                case "dropdown":
                    util_instances.all.push(new dropdown(element));
                    util_instances.dropdown.push(util_instances.all[util_instances.all.length - 1]);
                    break;

                case "modal":
                    util_instances.all.push(new modal(element));
                    util_instances.modal.push(util_instances.all[util_instances.all.length - 1]);
                    break;

                case "offcanvas":
                    util_instances.all.push(new offcanvas(element));
                    util_instances.modal.push(util_instances.all[util_instances.all.length - 1]);
                    break;

                default:
                    break;
            }
        }
    },

    /**
     * Get component object.
     * @param {string} id 
     * @returns {instance}
     */
    $: id => {
        for (let instance of util_instances.all) {
            if (instance.id === id) return instance;
        }
    }
}

/**
 * Execute when document DOM is loaded to make sure all elements have been
 * completely rendered.
 */
document.addEventListener("DOMContentLoaded", () => {
    baseComponentJs.init();
        
    // Handle scenario when element is created after "DomContentLoaded" event
    // to register new component.
    document.body.addEventListener('DOMNodeInserted', () => {
        baseComponentJs.init();
    });
});


/* harmony default export */ const base_component = (baseComponentJs);
;// CONCATENATED MODULE: ./src/index.js



// Pass "baseComponentJs" to be used as a global object.
window.baseComponentJs = base_component;
/******/ })()
;