# Base Component Js

This is the main scaffolding codes for [Base Component Js](https://mkfizi.github.io/base-component-js).

- [Download](#download)
- [Installation](#download)
-

## Download

Click [here](https://github.com/mkfizi/base-component-js/blob/main/downloads/base-component-js.zip?raw=true)
to download the scaffolder and unzip it's content to your project path to start 
building your own components using Base Component Js.

## Installation

Run below command to install dependencies.
```bash
npm install
```

Run below command to build Base Component JS codes.
```bash
npm run build
```

Alternatively, you may run below commands:
- `npm run build:dev` ─ Build for development.
- `npm run build:prod` ─ Build and minify for production.
- `npm run watch` ─ Build and watch for changes in real time.
- `npm run watch:dev` ─ Build for development and watch for changes in real time.
- `npm run watch:prod` ─ Build and minify for production and watch for changes in real time.

Insert below script inside `<head>` tag with `src` attribute's value referencing
to the location of the Base Component Js script.

```html
<script src="./src/js/base-component.js"></script>
```

That's it. You may begin use Base Component Js in your project. 

If you never heard of NPM before, this is the best time to start using it since
modern web development work best with NPM. Refer here for more informations:
[NPM](https://www.npmjs.com/)

> **Note:**
>
> By default, Base Component Js uses [Webpack v5](https://webpack.js.org/)
> bundler to build component and utility codes. You may use whatever bundlers
> according to your preference or project requirements.

## Usage & implementations

Base Component Js is a component scaffolder where you will need to write own
activities for each components. Out of the box, it comes with components as
below:
- Alert
- Collapse
- Dropdown
- Modal
- Offcanvas

You may refer to `/examples` that's included in the scaffolder to get the idea
on how to write custom component activities and their usage in a project.

> **Note:**
>
> By default, Base Component Js uses ES6 module standards and therefore, 
> explaination below demonstrates usage that complies with ES6 module standards.
> You may modify the scaffolder accordingly to suit your preferred standards.

### The basic

All components are defined using `class` object type. Thse

### Component

All component classes

Typically, a component consists of below activities.
- `show()` 
- `hide()`
- `toggle()`


Base Component Js comes with scaffolding for below components.
* [Alert](#alert) 

Base Component Js components uses `Class` object to define meth

### Alert



To create an Alert component, create an element as below example:
```html
<div id="componentId" data-bc="alert">
    ...
</div>
```

Create an element to triggers Alert component behaviour.
```


### Adding custom components
To create a component, simply create an element with `id` and `data-bc`
attributes as below example.
```html
<div id="componentId" data-bc="componentName">
    ...
</div>
```

Create an element with `aria-controls` which triggers above component as below
example.
```html
<button aria-controls="componentName">
    ...
</button>
```

You may add optional `aria-expanded




## Contributing

Pull requests are welcome. For major changes, please open an issue first to
discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://github.com/mkfizi/base-component-js/blob/main/LICENSE)