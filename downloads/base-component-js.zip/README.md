# Base Component Js

This is the main scaffolder codes for [Base Component Js](https://mkfizi.github.io/base-component-js).

- [Download](#download)
- [Installation](#installation)
- [Usage](#usage)
    - [The basics](#the-basics)
    - [Alert Component](#alert-component)

## Download

Click [here](https://github.com/mkfizi/base-component-js/blob/main/downloads/base-component-js.zip?raw=true)
to download the scaffolder and unzip it's content to your project path to start 
building your own components using Base Component Js.

## Installation

Run below command to install dependencies.
```bash
npm install
```

Run below command to build Base Component JS codes.
```bash
npm run build
```

Alternatively, you may run below commands:
- `npm run build:dev` ─ Build for development.
- `npm run build:prod` ─ Build and minify for production.
- `npm run watch` ─ Build and watch for changes in real time.
- `npm run watch:dev` ─ Build for development and watch for changes in real time.
- `npm run watch:prod` ─ Build and minify for production and watch for changes in real time.

Insert below script inside `<head>` tag with `src` attribute's value referencing
to the location of the Base Component Js script.

```html
<script src="./src/js/base-component.js"></script>
```

That's it. You may begin to use Base Component Js in your project. 

If you never heard of NPM before, this is the best time to start using it since modern web development work best with NPM. Refer [NPM](https://www.npmjs.com/) for more informations.


> **Note:**
By default, Base Component Js uses [Webpack v5](https://webpack.js.org/) bundler to build component and utility codes. You may use whatever bundlers according to your preference or project requirements.

## Usage

All components are initialized in `base-component.js` located in `/js` subdirectory. These components are defined in `/js/src` subdirectory and uses utilities from `/js/src/util` subdirectory. Component instances can be called globally using `$` to manually trigger activities.

> **Note:**
You may refer to `/example` subdirectory that's included in the scaffolder to get the idea on how to write custom component activities and their usage in a project.

### The basics

Component elements in HTML consists of a "content" and a "trigger". A "content" must contain `[id]` and `[data-bc]` attributes while "trigger" must contain `[aria-controls]` attribute referencing to content `[id]` attribute value. Additional attributes such as `[aria-expanded]`, `[data-bc-toggle]` may requires to be included in some "contents" and "triggers" depending on component type.

Components classes are inherited from `Component` class and usually consists of `show()`, `hide()` and `toggle()` methods. However, some components may contain custom methods to execute activities that are unique to them. These classes can located in `/js/src` subdirectory.

Utility objects are used to execute external activities on some components such as focus traping and enable or disable tab on elements. Depending on component activities, some utilities are required to be imported in Component classes. These utility objects can be located in `/js/src/util`. 

> **Note:**
By default, Base Component Js uses ES6 module standards and therefore, explaination below demonstrates usage that complies with ES6 module standards. You may modify the scaffolder accordingly to suit your preferred standards.

### Alert Component

Alert component can be initialized in HTML as below:
```html
<!-- Trigger -->
<button type="button" aria-controls="hide" data-bc-toggle="hide">Trigger</button>

<!-- Content -->
<div id="componentId" data-bc="alert">
    Content
</div>
```

Alert "content" attributes are as below:
| Attribute | Type | Default Value | Requisite | Detail |
|-----------|--------|------|---------------|-----------|
| `[id]` | `string` | null | Required | Alert name |
| `[data-bc]` | `string` | alert | Required | Component type |

Alert "trigger" attributes are as below:
| Attribute | Type | Default Value | Requisite | Detail |
|-----------|--------|------|---------------|-----------|
| `[aria-controls]` | `string` | null | Required | Alert name referencing to `[id]` value in "content" |
| `[data-bc-toggle]` | `string` | hide | Optional | Trigger type |

Alert class object properties are as below:
| Property | Type | Default Value | Detail |
|----------|------|---------------|--------|
| `element` | element | null | Alert "content" |
| `id` | string | null | Alert "content" `[id]` attribute value |
| `controls` | array | null | Alert "triggers" element |

Alert class object method is as below:
| Method | Detail |
|--------|--------|
| `hide()` | Execute activities to hide Alert |

To insert activies, modify the codes in `/js/src/alert.js` as example below:
```javascript
class Alert extends Component {
    ...
    hide() {
        ...
        // -------------------------< Put additional codes here >-------------------------
        this.element.classList.add("hide"); // Adds "hide" to alert "content" [class].
    }
}
```

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License
[MIT](https://github.com/mkfizi/base-component-js/blob/main/LICENSE)