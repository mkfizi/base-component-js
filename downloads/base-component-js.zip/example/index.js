import "./src/css/styles.css";
import script from "./src/js/script.js";
import baseComponentJs from "./src/js/base-component-js/base-component.js";

// Pass "baseComponentJs" to be used as a global object.
window.baseComponentJs = baseComponentJs;