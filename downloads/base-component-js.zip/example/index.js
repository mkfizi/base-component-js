import "./src/css/styles.css";
import baseComponentJs from "./src/js/base-component-js/base-component.js";
import script from "./src/js/script.js";

// Pass "baseComponentJs" to be used as a global object.
window.baseComponentJs = baseComponentJs;