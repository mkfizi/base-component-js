import "./css/styles.css";
import baseComponentJs from "./js/base-component.js";

// Pass "baseComponentJs" to be used as a global object.
window.baseComponentJs = baseComponentJs;